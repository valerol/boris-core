# SPDX-License-Identifier: MIT
"""BOIS:SIMA&BORIS public release package."""
__version__ = "1.4.8"
__boris_ego_version__ = "1.5"
