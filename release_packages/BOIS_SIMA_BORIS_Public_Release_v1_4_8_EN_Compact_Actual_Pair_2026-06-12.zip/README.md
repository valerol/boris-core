# BOIS:SIMA&BORIS Public Release [публичный релиз] v1.4.8

## Equal entry [равный вход]

- العربية: `docs/ar/INDEX.md`; `docs/ar/USER_MANUAL_SHORT.md`; `docs/ar/USER_MANUAL_FULL.md`.
- 中文: `docs/zh/INDEX.md`; `docs/zh/USER_MANUAL_SHORT.md`; `docs/zh/USER_MANUAL_FULL.md`.
- English [английский язык]: `docs/en/INDEX.md`; `docs/en/USER_MANUAL_SHORT.md`; `docs/en/USER_MANUAL_FULL.md`.
- Français: `docs/fr/INDEX.md`; `docs/fr/USER_MANUAL_SHORT.md`; `docs/fr/USER_MANUAL_FULL.md`.
- Русский: `docs/ru/INDEX.md`; `docs/ru/USER_MANUAL_SHORT.md`; `docs/ru/USER_MANUAL_FULL.md`.
- Español: `docs/es/INDEX.md`; `docs/es/USER_MANUAL_SHORT.md`; `docs/es/USER_MANUAL_FULL.md`.

`START_HERE_UN.md` and [и] `UN_LANGUAGE_INDEX.md` are neutral public entry points [нейтральные публичные точки входа].

## Active kernel [активное ядро]

```text
BOIS [бизнес-операционная интеллектуальная система] / BORIS [рациональная операционно-интеллектуальная система бизнеса] main [основная линия] v2.21 + SIMA [Substrate-Independent Machine Analyzer / субстрато-независимый машинный анализатор] v0.4 + BORIS EGO [Ethical Goal Orchestrator / этический оркестратор производных целей] v1.5
Public Release [публичный релиз] v1.4.8
```

Active core reference [ссылка на активное ядро]: `core/ACTIVE_CORE_REFERENCE_v1_4_8.md`.

## Packaging change [упаковочное изменение] v1.4.8

This release [релиз] implements Method 3 [метод 3], Method 6 [метод 6] and Method 7 [метод 7]: manifest-only history [история только через манифест], canonical-copy packaging [упаковка с единственной канонической копией], and archive role separation [разделение ролей архивов].

Public release [публичный релиз] and FULL_ACTUAL_COMPACT [полная актуальная компактная версия] are separate deliverables [отдельные артефакты]. Old full historical archives [старые полные исторические архивы] are not nested [не вкладываются] into the compact working archive [компактный рабочий архив].

## Local run [локальный запуск]

```bash
python -m bois_sima_boris docs --lang en
python -m bois_sima_boris docs --lang ru
python -m bois_sima_boris ego-status
python -m bois_sima_boris validate examples/example_local_workflow.json
python -m bois_sima_boris self-check --root .
python -m pytest
```

Optional offline editable installation [опциональная офлайн-установка в редактируемом режиме]:

```bash
python -m pip install --no-index -e .
```

Release boundary [граница релиза]: this is not a field-validated governance system [не полевая валидированная система управления], not a high-stakes decision system [не система принятия высокорисковых решений], not autonomous coercive governance [не автономное принудительное управление], and not proof of machine consciousness [не доказательство машинного сознания].
