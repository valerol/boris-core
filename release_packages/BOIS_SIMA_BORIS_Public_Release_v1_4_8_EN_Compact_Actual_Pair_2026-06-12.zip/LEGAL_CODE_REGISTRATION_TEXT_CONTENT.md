# Legal Code Registration Text Content [текстовое содержание для регистрации кода]

Active document [активный документ]: `legal/copyright/BOIS_PUBLIC_ARCHIVE_LEGAL_CODE_REGISTRATION_TEXT_CONTENT_v1_4_8_RU_EN.md`.

Word document [документ Word]: `legal/copyright/BOIS_PUBLIC_ARCHIVE_LEGAL_CODE_REGISTRATION_TEXT_CONTENT_v1_4_8_RU_EN.docx`.

Full source code text [полный текст исходного кода]: `legal/copyright/BOIS_PUBLIC_ARCHIVE_SOURCE_CODE_FULL_v1_4_8.txt`.

Full archive text extract [полная текстовая выгрузка архива]: `legal/copyright/BOIS_PUBLIC_ARCHIVE_FULL_TEXT_CONTENT_v1_4_8.txt`.

Manifest [манифест]: `legal/copyright/BOIS_PUBLIC_ARCHIVE_TEXT_MANIFEST_v1_4_8.json`.

Rule [правило]: BR-112 — Legal Code Registration Text Content Companion Rule [правило сопровождения текстовым содержанием для регистрации кода].
